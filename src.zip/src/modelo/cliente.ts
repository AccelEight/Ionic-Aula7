export class Cliente{
    id: number;
  nome: string;
  fone: string;
  email: string;
}